# 📡 INTEGRACIÓN REST API - FRONTEND Y BACKEND

## 🎯 Descripción General

La integración entre **Frontend (React)** y **Backend (Node.js)** se realiza mediante comunicación **REST** utilizando formato **JSON**. El frontend consume los endpoints del backend para:

✅ Obtener productos  
✅ Autenticar usuarios  
✅ Gestionar carrito  
✅ Crear y consultar pedidos  
✅ Administrar productos (solo admin)  

**Flujo de datos:**
```
Frontend (React) → HTTP Request → Backend (Express)
Backend → JSON Response → Frontend → Actualiza estado/UI
```

---

## 📁 ARQUITECTURA: `/src/utils/api.js`

### Función Principal: `fetchJson()`

```javascript
// Archivo: src/utils/api.js
const API_URL = "http://localhost:3001/api";

export async function fetchJson(endpoint, options = {}) {
  // Obtener token del localStorage
  const token = localStorage.getItem('token');
  
  const config = {
    headers: {
      "Content-Type": "application/json",
      ...(token && { "Authorization": `Bearer ${token}` }),
      ...(options.headers || {})
    },
    ...options
  };

  console.log(`📡 ${options.method || 'GET'} ${endpoint}`, {
    hasToken: !!token,
    headers: config.headers
  });

  const res = await fetch(API_URL + endpoint, config);

  let data = null;

  try {
    data = await res.json();
  } catch (e) {
    console.error('Error parseando JSON:', e);
    // Si la API no devuelve JSON, continuar
  }

  console.log(`Response Status: ${res.status}`, data);

  if (!res.ok) {
    const errorMessage = data?.error || data?.message || "Error en la API";
    console.error(`❌ Error ${res.status}:`, errorMessage);
    throw new Error(errorMessage);
  }

  return data;
}
```

**Características clave:**
- ✅ Manejo automático de tokens JWT
- ✅ Headers configurados (Content-Type, Authorization)
- ✅ Parseo seguro de JSON
- ✅ Logging en consola para debugging
- ✅ Gestión de errores con mensajes descriptivos

---

## 🔐 AUTENTICACIÓN - LOGIN Y REGISTRO

### 1️⃣ Endpoint: `POST /api/auth/login`

**Código Frontend:**
```javascript
export async function login(email, password) {
  const response = await fetchJson('/auth/login', {
    method: 'POST',
    body: JSON.stringify({ email, password })
  });

  if (response.token) {
    localStorage.setItem('token', response.token);
    localStorage.setItem('usuario', JSON.stringify(response.usuario));
    localStorage.setItem('role', response.usuario.role);
  }

  return response;
}
```

**Request JSON (enviado):**
```json
POST http://localhost:3001/api/auth/login
Content-Type: application/json

{
  "email": "admin@tienda.com",
  "password": "admin123"
}
```

**Response JSON (recibido):**
```json
{
  "success": true,
  "message": "Login exitoso",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "usuario": {
    "id": 1,
    "nombre": "Admin",
    "email": "admin@tienda.com",
    "role": "ADMIN"
  }
}
```

**Console Output en Frontend:**
```
📡 POST /auth/login {hasToken: false, headers: {...}}
Response Status: 200 {success: true, message: "Login exitoso", ...}
```

---

### 2️⃣ Endpoint: `POST /api/auth/register`

**Código Frontend:**
```javascript
export async function register(nombre, email, password) {
  const response = await fetchJson('/auth/register', {
    method: 'POST',
    body: JSON.stringify({ nombre, email, password })
  });

  if (response.token) {
    localStorage.setItem('token', response.token);
    localStorage.setItem('usuario', JSON.stringify(response.usuario));
    localStorage.setItem('role', response.usuario.role);
  }

  return response;
}
```

**Request JSON:**
```json
POST http://localhost:3001/api/auth/register
Content-Type: application/json

{
  "nombre": "Juan Pérez",
  "email": "juan@example.com",
  "password": "Password123!"
}
```

**Response JSON:**
```json
{
  "success": true,
  "message": "Registro exitoso",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "usuario": {
    "id": 2,
    "nombre": "Juan Pérez",
    "email": "juan@example.com",
    "role": "USER"
  }
}
```

---

## 📦 PRODUCTOS - CRUD OPERATIONS

### 3️⃣ Endpoint: `GET /api/productos` (Obtener todos)

**Código Frontend (ProductosContext.js):**
```javascript
async function cargarProductos() {
  setCargando(true);
  try {
    const response = await fetchJson('/productos');
    setProductos(response.data);
    setError(null);
  } catch (err) {
    setError(err.message);
    console.error('Error cargando productos:', err);
  } finally {
    setCargando(false);
  }
}
```

**Request:**
```
GET http://localhost:3001/api/productos
Content-Type: application/json
```

**Response JSON (Completo):**
```json
{
  "success": true,
  "message": "Productos obtenidos correctamente",
  "data": [
    {
      "id": 1,
      "nombre": "MacBook Pro 16\"",
      "descripcion": "Laptop profesional Apple",
      "precio": 3499000,
      "imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
      "categoria": "Electrónica",
      "stock": 5
    },
    {
      "id": 3,
      "nombre": "Magic Mouse",
      "descripcion": "Ratón inalámbrico Apple",
      "precio": 79000,
      "imagen": "https://images.unsplash.com/photo-1527814050087-3793815479db",
      "categoria": "Accesorios",
      "stock": 15
    },
    {
      "id": 4,
      "nombre": "Magic Keyboard",
      "descripcion": "Teclado inalámbrico Apple",
      "precio": 149000,
      "imagen": "https://images.unsplash.com/photo-1587829191301-1b9e9f9e8f9e",
      "categoria": "Accesorios",
      "stock": 12
    },
    {
      "id": 5,
      "nombre": "AirPods Pro",
      "descripcion": "Auriculares con cancelación de ruido",
      "precio": 349000,
      "imagen": "https://images.unsplash.com/photo-1505740420928-5e560c06d30e",
      "categoria": "Audio",
      "stock": 20
    },
    {
      "id": 6,
      "nombre": "iPad Air",
      "descripcion": "Tablet Apple de 11 pulgadas",
      "precio": 999000,
      "imagen": "https://images.unsplash.com/photo-1452587925148-ce544e77e70d",
      "categoria": "Tablets",
      "stock": 8
    },
    {
      "id": 7,
      "nombre": "Monitor LG 27\"",
      "descripcion": "Monitor 4K profesional",
      "precio": 599000,
      "imagen": "https://images.unsplash.com/photo-1527864550417-7fd91fc51a46",
      "categoria": "Monitores",
      "stock": 10
    }
  ]
}
```

**Console Output:**
```
📡 GET /productos {hasToken: true, headers: {...}}
Response Status: 200 {success: true, data: Array(6)}
```

**Vista en la App (Componente ProductCard):**
```
╔════════════════════════════════════════════╗
║     MacBook Pro 16"                        ║
║     [Imagen del producto]                  ║
║     Laptop profesional Apple               ║
║     Stock: 5 unidades                      ║
║     Precio: $3.499.000 CLP                 ║
║     [Botón: Agregar al Carrito]            ║
╚════════════════════════════════════════════╝
```

---

### 4️⃣ Endpoint: `POST /api/productos` (Crear - Solo Admin)

**Código Frontend (Admin):**
```javascript
export async function agregarProducto(producto) {
  const response = await fetchJson('/productos', {
    method: 'POST',
    body: JSON.stringify(producto)
  });
  return response;
}
```

**Request JSON:**
```json
POST http://localhost:3001/api/productos
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json

{
  "nombre": "Mac Mini",
  "descripcion": "Mini computadora Apple",
  "precio": 1299000,
  "imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
  "categoria": "Electrónica",
  "stock": 7
}
```

**Response JSON:**
```json
{
  "success": true,
  "message": "Producto agregado correctamente",
  "data": {
    "id": 8,
    "nombre": "Mac Mini",
    "descripcion": "Mini computadora Apple",
    "precio": 1299000,
    "imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
    "categoria": "Electrónica",
    "stock": 7
  }
}
```

---

### 5️⃣ Endpoint: `PUT /api/productos/:id` (Actualizar - Solo Admin)

**Request JSON:**
```json
PUT http://localhost:3001/api/productos/1
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json

{
  "nombre": "MacBook Pro 16\" - Edición Especial",
  "precio": 3999000,
  "stock": 3
}
```

**Response JSON:**
```json
{
  "success": true,
  "message": "Producto actualizado correctamente",
  "data": {
    "id": 1,
    "nombre": "MacBook Pro 16\" - Edición Especial",
    "descripcion": "Laptop profesional Apple",
    "precio": 3999000,
    "imagen": "https://images.unsplash.com/photo-1517336714731-489689fd1ca8",
    "categoria": "Electrónica",
    "stock": 3
  }
}
```

---

### 6️⃣ Endpoint: `DELETE /api/productos/:id` (Eliminar - Solo Admin)

**Request:**
```
DELETE http://localhost:3001/api/productos/8
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
```

**Response JSON:**
```json
{
  "success": true,
  "message": "Producto eliminado correctamente",
  "data": {
    "id": 8,
    "nombre": "Mac Mini",
    "precio": 1299000
  }
}
```

---

## 🛒 CARRITO - OPERACIONES

### 7️⃣ Agregar al Carrito (Local State)

**Código Frontend (CarritoContext.jsx):**
```javascript
const agregarAlCarrito = useCallback((producto) => {
  setCarrito(prev => {
    const existente = prev.find(item => item.id === producto.id);
    
    if (existente) {
      return prev.map(item =>
        item.id === producto.id
          ? { ...item, cantidad: item.cantidad + 1 }
          : item
      );
    }
    
    return [...prev, { ...producto, cantidad: 1 }];
  });
}, []);
```

**Vista en la App (Carrito):**
```
╔═════════════════════════════════════════════════════╗
║ 🛒 CARRITO DE COMPRAS                               ║
╠═════════════════════════════════════════════════════╣
║ MacBook Pro 16"          × 1    $3.499.000         ║
║ Magic Mouse              × 2    $158.000           ║
║ AirPods Pro              × 1    $349.000           ║
╠═════════════════════════════════════════════════════╣
║ SUBTOTAL:                        $4.006.000        ║
║ IVA (19%):                       $761.140          ║
║ TOTAL:                           $4.767.140        ║
║                                                     ║
║ [Botón: Proceder al Checkout]                      ║
╚═════════════════════════════════════════════════════╝
```

---

## 📋 PEDIDOS - CRUD OPERATIONS

### 8️⃣ Endpoint: `POST /api/pedidos` (Crear Pedido)

**Código Frontend (PedidosContext.js):**
```javascript
async function crearPedido(pedidoData) {
  setCargando(true);
  try {
    const response = await fetchJson('/pedidos', {
      method: 'POST',
      body: JSON.stringify(pedidoData)
    });
    setPedidos(prev => [...prev, response.data]);
    return response.data;
  } catch (err) {
    setError(err.message);
    throw err;
  } finally {
    setCargando(false);
  }
}
```

**Request JSON:**
```json
POST http://localhost:3001/api/pedidos
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json

{
  "items": [
    {
      "id": 1,
      "nombre": "MacBook Pro 16\"",
      "precio": 3499000,
      "cantidad": 1
    },
    {
      "id": 5,
      "nombre": "AirPods Pro",
      "precio": 349000,
      "cantidad": 1
    }
  ],
  "total": 3848000,
  "cliente": {
    "nombre": "Juan Pérez",
    "email": "juan@example.com",
    "telefono": "+56912345678",
    "direccion": "Calle Principal 123, Santiago",
    "comuna": "Providencia",
    "region": "Metropolitana"
  }
}
```

**Response JSON:**
```json
{
  "success": true,
  "message": "Pedido creado exitosamente",
  "data": {
    "id": "PED-2025-001",
    "fecha": "2025-12-17T10:30:00Z",
    "items": [
      {
        "id": 1,
        "nombre": "MacBook Pro 16\"",
        "precio": 3499000,
        "cantidad": 1
      },
      {
        "id": 5,
        "nombre": "AirPods Pro",
        "precio": 349000,
        "cantidad": 1
      }
    ],
    "total": 3848000,
    "estado": "PENDIENTE",
    "cliente": {
      "nombre": "Juan Pérez",
      "email": "juan@example.com",
      "telefono": "+56912345678",
      "direccion": "Calle Principal 123, Santiago",
      "comuna": "Providencia",
      "region": "Metropolitana"
    }
  }
}
```

**Vista en la App (Confirmación):**
```
╔═════════════════════════════════════════════════════╗
║ ✅ PEDIDO CONFIRMADO                                ║
╠═════════════════════════════════════════════════════╣
║ Número de Pedido: PED-2025-001                      ║
║ Fecha: 17/12/2025 10:30                            ║
║                                                     ║
║ PRODUCTOS:                                          ║
║ - MacBook Pro 16" × 1 ................. $3.499.000  ║
║ - AirPods Pro × 1 ..................... $349.000    ║
║                                                     ║
║ TOTAL: $3.848.000                                   ║
║                                                     ║
║ ESTADO: 🟡 PENDIENTE                               ║
║                                                     ║
║ [Botón: Descargar Recibo] [Ir a Mis Pedidos]      ║
╚═════════════════════════════════════════════════════╝
```

---

### 9️⃣ Endpoint: `GET /api/pedidos` (Obtener Pedidos del Usuario)

**Request:**
```
GET http://localhost:3001/api/pedidos
Authorization: Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
Content-Type: application/json
```

**Response JSON:**
```json
{
  "success": true,
  "message": "Pedidos obtenidos correctamente",
  "data": [
    {
      "id": "PED-2025-001",
      "fecha": "2025-12-17T10:30:00Z",
      "total": 3848000,
      "estado": "PENDIENTE",
      "items": [
        {
          "id": 1,
          "nombre": "MacBook Pro 16\"",
          "precio": 3499000,
          "cantidad": 1
        },
        {
          "id": 5,
          "nombre": "AirPods Pro",
          "precio": 349000,
          "cantidad": 1
        }
      ]
    },
    {
      "id": "PED-2025-002",
      "fecha": "2025-12-16T14:15:00Z",
      "total": 237000,
      "estado": "ENTREGADO",
      "items": [
        {
          "id": 3,
          "nombre": "Magic Mouse",
          "precio": 79000,
          "cantidad": 3
        }
      ]
    }
  ]
}
```

**Vista en la App (Mis Pedidos):**
```
╔═════════════════════════════════════════════════════╗
║ 📦 MIS PEDIDOS                                      ║
╠═════════════════════════════════════════════════════╣
║ Pedido: PED-2025-001                               ║
║ Fecha: 17/12/2025 10:30                            ║
║ Items: 2 productos                                  ║
║ Total: $3.848.000                                   ║
║ Estado: 🟡 PENDIENTE                               ║
║ [Ver Detalles]                                      ║
╠═════════════════════════════════════════════════════╣
║ Pedido: PED-2025-002                               ║
║ Fecha: 16/12/2025 14:15                            ║
║ Items: 1 producto                                   ║
║ Total: $237.000                                     ║
║ Estado: ✅ ENTREGADO                               ║
║ [Ver Detalles]                                      ║
╚═════════════════════════════════════════════════════╝
```

---

## 🔄 FLUJO COMPLETO: LOGIN → COMPRA → PEDIDO

### Paso a Paso Visual:

**1. Usuario hace Login:**
```
Frontend Input → (email: admin@tienda.com, password: admin123)
         ↓
POST /api/auth/login (JSON)
         ↓
Backend valida credenciales
         ↓
Response: {token: "jwt...", usuario: {...}}
         ↓
Frontend guarda token en localStorage
         ↓
Redirige a Home
```

**2. Usuario navega a Productos:**
```
Frontend renderiza Productos.jsx
         ↓
useEffect → GET /api/productos
         ↓
Backend devuelve array de 6 productos
         ↓
Frontend actualiza ProductosContext.estado
         ↓
Renderiza ProductCard para cada producto
         ↓
Usuario ve 6 tarjetas con imágenes y precios
```

**3. Usuario agrega al carrito:**
```
Click en "Agregar al Carrito"
         ↓
agregarAlCarrito(producto) se ejecuta
         ↓
CarritoContext.estado se actualiza (LOCAL)
         ↓
Navbar muestra badge: "🛒 2 items"
         ↓
Carrito.jsx lista todos los items
```

**4. Usuario va a Checkout:**
```
Click en "Proceder al Checkout"
         ↓
Checkout.jsx muestra resumen
         ↓
Usuario completa formulario
         ↓
Click en "Confirmar Pedido"
         ↓
POST /api/pedidos (con token JWT)
         ↓
Backend crea pedido en memoria
         ↓
Response: {id: "PED-2025-001", ...}
         ↓
Frontend redirige a PedidoConfirmado.jsx
         ↓
Usuario ve confirmación con número de pedido
```

---

## 📊 TABLA RESUMEN: ENDPOINTS

| Método | Endpoint | Autenticación | Rol | Descripción |
|--------|----------|---|---|---|
| **POST** | `/api/auth/login` | ❌ No | Público | Login usuario |
| **POST** | `/api/auth/register` | ❌ No | Público | Registrar usuario |
| **GET** | `/api/auth/me` | ✅ JWT | Cualquiera | Datos usuario actual |
| **GET** | `/api/productos` | ✅ JWT | Cualquiera | Obtener todos productos |
| **POST** | `/api/productos` | ✅ JWT | ADMIN | Crear producto |
| **PUT** | `/api/productos/:id` | ✅ JWT | ADMIN | Actualizar producto |
| **DELETE** | `/api/productos/:id` | ✅ JWT | ADMIN | Eliminar producto |
| **POST** | `/api/pedidos` | ✅ JWT | Cualquiera | Crear pedido |
| **GET** | `/api/pedidos` | ✅ JWT | Cualquiera | Obtener pedidos usuario |
| **GET** | `/api/pedidos/:id` | ✅ JWT | Cualquiera | Obtener detalles pedido |

---

## 🔒 SEGURIDAD - JWT TOKENS

### Cómo funciona:

1. **Login exitoso** → Backend genera JWT token
2. **Frontend guarda** token en localStorage
3. **Cada request** incluye: `Authorization: Bearer <token>`
4. **Backend valida** token antes de procesar
5. **Token expira** cuando sesión termina

**Token JWT estructura:**
```
eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.
eyJpZCI6MSwibm9tYnJlIjoiQWRtaW4iLCJyb2xlIjoiQURNSU4ifQ.
signature...

Decodificado:
{
  "id": 1,
  "nombre": "Admin",
  "role": "ADMIN"
}
```

---

## ⚠️ MANEJO DE ERRORES

### Error 401 - No autorizado:
```javascript
// Request sin token a endpoint protegido
GET /api/pedidos
// Response:
{
  "success": false,
  "message": "Token no proporcionado o inválido",
  "code": 401
}
```

### Error 403 - Prohibido:
```javascript
// Usuario regular intenta crear producto
POST /api/productos (sin rol ADMIN)
// Response:
{
  "success": false,
  "message": "No tienes permisos para esta acción",
  "code": 403
}
```

### Error 404 - No encontrado:
```javascript
// Solicitar producto inexistente
GET /api/productos/999
// Response:
{
  "success": false,
  "message": "Producto no encontrado",
  "code": 404
}
```

---

## 📱 EJEMPLO: VISTA COMPLETA EN LA APP

**Pantalla 1: Login**
```
┌─────────────────────────────────┐
│  TIENDA ONLINE                  │
├─────────────────────────────────┤
│  Email:     [admin@tienda.com]  │
│  Password:  [••••••••••]         │
│                                 │
│  [Entrar]  [Registrarse]        │
└─────────────────────────────────┘
```

**Pantalla 2: Productos**
```
┌─────────────────────────────────┐
│  PRODUCTOS (6 disponibles) 🛒 0  │
├─────────────────────────────────┤
│                                 │
│  ┌──────────┐  ┌──────────┐    │
│  │MacBook   │  │Magic     │    │
│  │Pro 16"   │  │Mouse     │    │
│  │          │  │          │    │
│  │$3.499.000│  │$79.000   │    │
│  │[Agregar] │  │[Agregar] │    │
│  └──────────┘  └──────────┘    │
│                                 │
│  ... (4 productos más)          │
└─────────────────────────────────┘
```

**Pantalla 3: Carrito**
```
┌─────────────────────────────────┐
│  🛒 CARRITO (3 items)            │
├─────────────────────────────────┤
│ MacBook Pro 16"    × 1 $3.499.00│
│ Magic Mouse        × 2 $158.000 │
│ AirPods Pro        × 1 $349.000 │
├─────────────────────────────────┤
│ TOTAL: $4.006.000               │
│ [Proceder al Checkout]          │
└─────────────────────────────────┘
```

**Pantalla 4: Confirmación Pedido**
```
┌─────────────────────────────────┐
│ ✅ ¡PEDIDO CONFIRMADO!          │
├─────────────────────────────────┤
│ Número: PED-2025-001            │
│ Fecha: 17/12/2025 10:30         │
│ Total: $4.006.000               │
│                                 │
│ Estado: 🟡 PENDIENTE            │
│                                 │
│ [Descargar Recibo]              │
│ [Ir a Mis Pedidos]              │
└─────────────────────────────────┘
```

---

## 🎯 CONCLUSIÓN

La integración REST entre frontend y backend garantiza:

✅ **Separación de responsabilidades** - Frontend (UI), Backend (lógica)  
✅ **Comunicación eficiente** - JSON format, HTTP estándar  
✅ **Seguridad** - Tokens JWT, autorización por roles  
✅ **Escalabilidad** - Fácil de expandir con nuevos endpoints  
✅ **Debugging** - Logs en consola para rastrear requests/responses  

**Estados de la aplicación fluyen así:**
```
Redux/Context API (Frontend) → Fetch API → Express API (Backend)
     ↑                                            ↓
     └────────── JSON Response ────────────────┘
```

Cada cambio se refleja **inmediatamente** en la UI gracias a React's state management.

---

**Creado:** 17/12/2025  
**Archivo:** INTEGRACION_REST_API.md
