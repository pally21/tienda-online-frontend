# 🖥️ ESTRUCTURA DEL BACKEND

## 📊 Estado Actual

```
✅ Backend:       CORRIENDO
✅ Puerto:        3001
✅ Tipo:          Node.js + Express
✅ URL:           http://localhost:3001/api
✅ Proceso:       node server-demo.js (PID: 74694)
```

---

## 🌐 ENDPOINTS API

### 1️⃣ Obtener Productos (PÚBLICO)

```http
GET /api/productos
```

**Respuesta (200 OK):**
```json
{
  "success": true,
  "data": [
    {
      "id": 1,
      "nombre": "Camisa Casual",
      "descripcion": "Camisa de algodón para uso casual",
      "precio": 49990,
      "stock": 25,
      "categoria": "Ropa",
      "imagen": "https://images.unsplash.com/..."
    },
    {
      "id": 2,
      "nombre": "Zapatos Deportivos",
      "descripcion": "Zapatos cómodos para deportes y uso diario",
      "precio": 89990,
      "stock": 20,
      "categoria": "Calzado",
      "imagen": "https://images.unsplash.com/..."
    },
    ...
  ]
}
```

---

### 2️⃣ Login (PÚBLICO)

```http
POST /api/auth/login
Content-Type: application/json

{
  "email": "admin@tienda.com",
  "password": "admin123"
}
```

**Respuesta (200 OK):**
```json
{
  "success": true,
  "message": "Login exitoso",
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  "usuario": {
    "id": 1,
    "nombre": "Admin Tienda",
    "email": "admin@tienda.com",
    "role": "ADMIN"
  }
}
```

**Errores:**
- 400: Email o contraseña incorrectos
- 404: Usuario no encontrado

---

### 3️⃣ Registro (PÚBLICO)

```http
POST /api/auth/register
Content-Type: application/json

{
  "nombre": "Juan Pérez",
  "email": "juan@example.com",
  "password": "miPassword123"
}
```

**Respuesta (201 CREATED):**
```json
{
  "success": true,
  "message": "Usuario registrado exitosamente",
  "usuario": {
    "id": 2,
    "nombre": "Juan Pérez",
    "email": "juan@example.com",
    "role": "USER"
  }
}
```

---

### 4️⃣ Obtener Usuario Actual (AUTENTICADO)

```http
GET /api/auth/me
Authorization: Bearer <token>
```

**Respuesta (200 OK):**
```json
{
  "success": true,
  "message": "Usuario autenticado",
  "usuario": {
    "id": 1,
    "nombre": "Admin Tienda",
    "email": "admin@tienda.com",
    "role": "ADMIN"
  }
}
```

**Errores:**
- 401: Token no proporcionado
- 403: Token inválido

---

### 5️⃣ Crear Pedido (AUTENTICADO)

```http
POST /api/pedidos
Authorization: Bearer <token>
Content-Type: application/json

{
  "items": [
    {
      "id": 1,
      "nombre": "Camisa Casual",
      "precio": 49990,
      "cantidad": 2
    },
    {
      "id": 2,
      "nombre": "Zapatos Deportivos",
      "precio": 89990,
      "cantidad": 1
    }
  ],
  "total": 189970,
  "cliente": {
    "nombre": "Juan Pérez",
    "email": "juan@example.com",
    "telefono": "+56912345678",
    "direccion": "Calle Principal 123, Santiago",
    "comuna": "Providencia",
    "region": "Metropolitana"
  }
}
```

**Respuesta (201 CREATED):**
```json
{
  "success": true,
  "message": "Pedido creado exitosamente",
  "pedido": {
    "id": "PED-2025-001",
    "usuarioId": 1,
    "items": [...],
    "total": 189970,
    "estado": "PENDIENTE",
    "fechaCreacion": "2025-12-17T10:30:45Z",
    "cliente": {...}
  }
}
```

---

### 6️⃣ Obtener Pedidos del Usuario (AUTENTICADO)

```http
GET /api/pedidos
Authorization: Bearer <token>
```

**Respuesta (200 OK):**
```json
{
  "success": true,
  "message": "Pedidos obtenidos",
  "pedidos": [
    {
      "id": "PED-2025-001",
      "usuarioId": 1,
      "items": [...],
      "total": 189970,
      "estado": "PENDIENTE",
      "fechaCreacion": "2025-12-17T10:30:45Z",
      "cliente": {...}
    }
  ]
}
```

---

### 7️⃣ Obtener Producto por ID (PÚBLICO)

```http
GET /api/productos/:id
```

**Respuesta (200 OK):**
```json
{
  "success": true,
  "data": {
    "id": 1,
    "nombre": "Camisa Casual",
    "descripcion": "Camisa de algodón para uso casual",
    "precio": 49990,
    "stock": 25,
    "categoria": "Ropa",
    "imagen": "https://images.unsplash.com/..."
  }
}
```

---

## 🔐 Autenticación

El backend utiliza **JWT (JSON Web Tokens)** para autenticar usuarios.

### Cómo funciona:

1. **Login**: Usuario envía email y password
2. **Token**: Backend retorna un JWT
3. **Uso**: Cliente incluye token en header `Authorization: Bearer <token>`
4. **Validación**: Backend valida el token en cada request protegido

### Credenciales de Prueba:

```
Email:    admin@tienda.com
Password: admin123
Role:     ADMIN
```

---

## 📦 PRODUCTOS DISPONIBLES

| ID | Nombre | Precio | Stock | Categoría |
|---|---|---|---|---|
| 1 | Camisa Casual | $49.990 | 25 | Ropa |
| 2 | Zapatos Deportivos | $89.990 | 20 | Calzado |
| 3 | Mochila Ejecutiva | $79.990 | 15 | Accesorios |
| 4 | Reloj Inteligente | $199.990 | 12 | Tecnología |
| 5 | Lentes de Sol | $69.990 | 30 | Accesorios |
| 6 | Cinturón Premium | $59.990 | 18 | Accesorios |

---

## 🧪 Ejemplos con CURL

### Obtener Productos:
```bash
curl http://localhost:3001/api/productos
```

### Login:
```bash
curl -X POST -H "Content-Type: application/json" \
  -d '{"email":"admin@tienda.com","password":"admin123"}' \
  http://localhost:3001/api/auth/login
```

### Obtener Usuario Autenticado:
```bash
TOKEN="tu_token_aqui"
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:3001/api/auth/me
```

### Crear Pedido:
```bash
TOKEN="tu_token_aqui"
curl -X POST \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{
    "items": [{"id":1,"nombre":"Camisa Casual","precio":49990,"cantidad":2}],
    "total": 99980,
    "cliente": {
      "nombre": "Juan Pérez",
      "email": "juan@test.com",
      "telefono": "+56912345678",
      "direccion": "Calle 123",
      "comuna": "Santiago",
      "region": "Metropolitana"
    }
  }' \
  http://localhost:3001/api/pedidos
```

---

## 📂 Estructura del Archivo

```javascript
server-demo.js
├── Imports (express, cors, jwt, bcryptjs)
├── Configuración (CORS, JWT_SECRET, parseJson)
├── Datos en Memoria
│   ├── usuarios[]
│   ├── pedidos[]
│   └── productos[]
├── Middlewares
│   ├── authenticateToken()
│   ├── authorize()
│   └── cors()
└── Rutas
    ├── GET  /api/productos
    ├── GET  /api/productos/:id
    ├── POST /api/auth/login
    ├── POST /api/auth/register
    ├── GET  /api/auth/me
    ├── POST /api/pedidos
    └── GET  /api/pedidos
```

---

## 💾 Almacenamiento de Datos

Todos los datos se almacenan **en memoria**:
- ✅ Los cambios existen mientras el servidor está corriendo
- ❌ Al reiniciar el servidor, se pierden todos los datos
- ✅ Perfecto para desarrollo y pruebas
- ❌ NO es apto para producción (usar base de datos real)

---

## 🔄 Conexión con Frontend

El frontend (React) se conecta automáticamente:

```javascript
// src/utils/api.js
const API_URL = 'http://localhost:3001/api';

// Ejemplo de llamada
const obtenerProductos = async () => {
  const response = await fetch(`${API_URL}/productos`);
  const data = await response.json();
  return data;
};

// Con token
const crearPedido = async (pedidoData, token) => {
  const response = await fetch(`${API_URL}/pedidos`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${token}`,
      'Content-Type': 'application/json'
    },
    body: JSON.stringify(pedidoData)
  });
  return await response.json();
};
```

---

## 🛠️ Administración del Backend

### Ver logs en tiempo real:
```bash
# Ver proceso corriendo
pgrep -f "node server-demo"

# Ver puertos en uso
lsof -i :3001

# Probar conexión
curl http://localhost:3001/api/productos
```

### Cambiar servidor:
```bash
# Detener servidor actual
pkill -f "node server-demo.js"

# Iniciar servidor alternativo
cd /Users/usuario/tienda-online-react/backend
node server.js
```

---

## ✅ Checklist de Verificación

- [ ] Backend corriendo en puerto 3001
- [ ] GET /api/productos retorna 6 productos
- [ ] POST /api/auth/login funciona con admin@tienda.com
- [ ] JWT token se genera correctamente
- [ ] GET /api/auth/me retorna usuario autenticado
- [ ] POST /api/pedidos crea pedido exitosamente
- [ ] GET /api/pedidos retorna lista de pedidos
- [ ] Frontend conecta sin errores CORS

---

## 📝 Notas

- **Base de datos**: En memoria (arrays JavaScript)
- **Persistencia**: NO (se reinicia al recargar servidor)
- **Seguridad**: JWT tokens con expiración
- **CORS**: Habilitado para localhost:3000 y localhost:3002
- **Validación**: Básica (email, password requeridos)
- **Encriptación**: bcryptjs para contraseñas

