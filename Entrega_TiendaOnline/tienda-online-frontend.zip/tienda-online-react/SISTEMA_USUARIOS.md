# 👥 Sistema de Gestión de Usuarios para Admin

## ✅ Descripción General

Se ha implementado un **sistema completo de gestión de usuarios** que permite al administrador:

- ✅ Ver lista completa de todos los usuarios registrados
- ✅ Ver estadísticas de usuarios (total, activos, suspendidos, con compras, etc.)
- ✅ Cambiar el estado de un usuario (activo, suspendido, inactivo)
- ✅ Eliminar usuarios (excepto el admin principal)
- ✅ Visualizar información detallada de cada usuario
- ✅ Datos persistentes en archivo JSON (sin necesidad de MongoDB)

---

## 📁 Archivos Creados/Modificados

### **Backend (Node.js)**

#### 1. **`/backend/data/usuarios.json`** (Nuevo)
```json
[
  {
    "id": 1,
    "nombre": "Admin Tienda",
    "email": "admin@tienda.com",
    "password": "hasheada",
    "role": "ADMIN",
    "estado": "activo",
    "fechaRegistro": "2025-01-01T00:00:00Z",
    "ultimaCompra": null
  },
  {
    "id": 2,
    "nombre": "Juan Pérez",
    "email": "juan@example.com",
    "password": "hasheada",
    "role": "USER",
    "estado": "activo",
    "fechaRegistro": "2025-12-10T14:30:00Z",
    "ultimaCompra": "2025-12-15T10:20:00Z"
  }
]
```

#### 2. **`/backend/utils/usuariosStore.js`** (Nuevo)
Sistema de almacenamiento de usuarios con las siguientes funciones:

```javascript
// Funciones disponibles:
- leerUsuarios()              // Lee todos los usuarios del JSON
- guardarUsuarios(usuarios)   // Guarda usuarios en JSON
- obtenerPorEmail(email)      // Busca usuario por email
- obtenerPorId(id)            // Busca usuario por ID
- agregarUsuario(datos)       // Crea nuevo usuario
- actualizarUsuario(id, datos) // Actualiza usuario
- eliminarUsuario(id)         // Elimina usuario
- obtenerTodos()              // Retorna todos sin passwords
- actualizarUltimaCompra(email) // Registra última compra
```

#### 3. **`/backend/server-demo.js`** (Actualizado)
Se agregaron:
- Importación de `usuariosStore`
- 5 nuevos endpoints para admin:

```
GET    /api/admin/usuarios
GET    /api/admin/usuarios/:id
PUT    /api/admin/usuarios/:id/estado
DELETE /api/admin/usuarios/:id
GET    /api/admin/estadisticas/usuarios
```

### **Frontend (React)**

#### 1. **`/src/pages/Admin/AdminUsuarios.jsx`** (Nuevo)
Componente React con:
- ✅ Tabla responsive de usuarios
- ✅ Tarjetas de estadísticas
- ✅ Modal para cambiar estado
- ✅ Confirmar eliminación de usuarios
- ✅ Manejo de errores y mensajes

#### 2. **`/src/pages/Admin/AdminUsuarios.css`** (Nuevo)
Estilos profesionales:
- Gradiente morado
- Tarjetas con hover effects
- Tabla con colores alternados
- Responsive en móvil
- Badges de colores

#### 3. **`/src/App.js`** (Actualizado)
- ✅ Importación de `AdminUsuarios`
- ✅ Nueva ruta: `/admin/usuarios`

#### 4. **`/src/components/Navbar/Navbar.jsx`** (Actualizado)
- ✅ Nuevo enlace: "👥 Usuarios" en el navbar para admin

---

## 🚀 Cómo Usar

### **Para el Admin:**

1. **Iniciar Sesión**
   - Email: `admin@tienda.com`
   - Contraseña: `admin123`

2. **Acceder al Panel de Usuarios**
   - Navbar → "👥 Usuarios"
   - O directamente: `http://localhost:3000/admin/usuarios`

3. **Funcionalidades Disponibles:**

   **a) Ver Lista de Usuarios**
   - Tabla con: ID, Nombre, Email, Rol, Estado, Fecha Registro, Última Compra
   - Información actualizada en tiempo real

   **b) Ver Estadísticas**
   - Total de usuarios
   - Usuarios activos
   - Usuarios suspendidos
   - Usuarios con compras

   **c) Cambiar Estado de Usuario**
   ```
   1. Click en botón "Estado"
   2. Seleccionar nuevo estado: Activo / Suspendido / Inactivo
   3. Confirmar cambio
   ```

   **d) Eliminar Usuario**
   ```
   1. Click en botón "Eliminar"
   2. Confirmar eliminación
   3. Usuario se borra de la base de datos
   ```

---

## 📊 Estructura de Datos del Usuario

```javascript
{
  "id": 1,                                    // ID único
  "nombre": "Juan Pérez",                     // Nombre completo
  "email": "juan@example.com",                // Email único
  "password": "$2a$10$...",                   // Password hasheada (bcrypt)
  "role": "USER" | "ADMIN",                   // Rol del usuario
  "estado": "activo" | "suspendido" | "inactivo", // Estado actual
  "fechaRegistro": "2025-12-10T14:30:00Z",   // Cuándo se registró
  "ultimaCompra": "2025-12-15T10:20:00Z"     // Última compra (null si no compró)
}
```

---

## 🔌 API Endpoints

### **Admin Users**

#### 1. **Obtener todos los usuarios**
```bash
GET /api/admin/usuarios
Authorization: Bearer <token_admin>

Response:
{
  "success": true,
  "message": "Total de usuarios: 4",
  "data": [
    {
      "id": 1,
      "nombre": "Admin Tienda",
      "email": "admin@tienda.com",
      "role": "ADMIN",
      "estado": "activo",
      ...
    }
  ]
}
```

#### 2. **Obtener usuario específico**
```bash
GET /api/admin/usuarios/:id
Authorization: Bearer <token_admin>

Response:
{
  "success": true,
  "data": { ... usuario data ... }
}
```

#### 3. **Cambiar estado de usuario**
```bash
PUT /api/admin/usuarios/:id/estado
Authorization: Bearer <token_admin>
Content-Type: application/json

Body:
{
  "estado": "suspendido"
}

Response:
{
  "success": true,
  "message": "Usuario usuario@example.com actualizado a estado: suspendido",
  "data": { ... usuario actualizado ... }
}
```

#### 4. **Eliminar usuario**
```bash
DELETE /api/admin/usuarios/:id
Authorization: Bearer <token_admin>

Response:
{
  "success": true,
  "message": "Usuario usuario@example.com eliminado correctamente"
}
```

#### 5. **Obtener estadísticas**
```bash
GET /api/admin/estadisticas/usuarios
Authorization: Bearer <token_admin>

Response:
{
  "success": true,
  "data": {
    "totalUsuarios": 4,
    "usuariosActivos": 3,
    "usuariosSuspendidos": 1,
    "usuariosInactivos": 0,
    "admins": 1,
    "usuariosRegulares": 3,
    "usuariosConCompras": 2
  }
}
```

---

## 🔒 Seguridad

✅ **Protecciones Implementadas:**

1. **JWT Authentication**
   - Solo admin con token válido puede acceder

2. **Role-Based Access Control**
   - Verificación de rol `ADMIN` en cada endpoint

3. **Validaciones**
   - No permite cambiar estado del admin principal
   - No permite eliminar al admin principal
   - Verificación de datos requeridos

4. **Password Hashing**
   - Passwords hasheadas con bcrypt
   - No se devuelven en respuestas API

5. **CORS Habilitado**
   - Solo desde frontend autorizado

---

## 📱 Vista del Panel (UI)

```
┌─────────────────────────────────────────────────────────┐
│  👥 Gestión de Usuarios                                 │
├─────────────────────────────────────────────────────────┤
│                                                         │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐             │
│  │   4      │  │   3      │  │   1      │             │
│  │ Total    │  │ Activos  │  │Suspendidos│            │
│  └──────────┘  └──────────┘  └──────────┘             │
│                                                         │
│  ID │ Nombre    │ Email          │ Rol    │ Estado    │
│  ───┼───────────┼────────────────┼────────┼─────────  │
│  1  │ Admin     │ admin@...      │ Admin  │ Activo    │
│  2  │ Juan      │ juan@...       │ User   │ Activo    │
│  3  │ María     │ maria@...      │ User   │ Activo    │
│  4  │ Carlos    │ carlos@...     │ User   │ Suspendido│
│                                                         │
│  [Estado] [Eliminar] ← Botones de acción              │
│                                                         │
└─────────────────────────────────────────────────────────┘
```

---

## 🧪 Pruebas Rápidas

### **Test 1: Ver lista de usuarios**
```bash
# 1. Login como admin
TOKEN=$(curl -X POST \
  -H "Content-Type: application/json" \
  -d '{"email":"admin@tienda.com","password":"admin123"}' \
  http://localhost:3001/api/auth/login | jq -r '.token')

# 2. Obtener usuarios
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:3001/api/admin/usuarios | jq
```

### **Test 2: Cambiar estado de usuario**
```bash
curl -X PUT \
  -H "Authorization: Bearer $TOKEN" \
  -H "Content-Type: application/json" \
  -d '{"estado":"suspendido"}' \
  http://localhost:3001/api/admin/usuarios/2
```

### **Test 3: Ver estadísticas**
```bash
curl -H "Authorization: Bearer $TOKEN" \
  http://localhost:3001/api/admin/estadisticas/usuarios | jq
```

---

## 💾 Persistencia de Datos

**Sin MongoDB - Usando JSON:**

✅ Los datos se guardan en `/backend/data/usuarios.json`

✅ Los datos persisten entre reinicios del servidor

✅ Automáticamente actualizado cuando se:
- Registra un usuario
- Cambia estado
- Elimina usuario
- Realiza compra

---

## 🎯 Características Implementadas

| Característica | Estado | Descripción |
|---|---|---|
| Ver todos los usuarios | ✅ | Tabla completa con información |
| Filtrar por estado | ✅ | Visual en badges de colores |
| Cambiar estado usuario | ✅ | Modal intuitivo |
| Eliminar usuario | ✅ | Con confirmación |
| Estadísticas | ✅ | Tarjetas numéricas |
| Persistencia | ✅ | Archivos JSON |
| Seguridad JWT | ✅ | Solo admin autenticado |
| Responsive | ✅ | Funciona en móvil |
| Manejo de errores | ✅ | Mensajes claros |

---

## 🔄 Flujo de Funcionamiento

```
Frontend → Request HTTP
    ↓
Backend (Express)
    ↓
Middleware: Verificar Token JWT
    ↓
Middleware: Verificar rol ADMIN
    ↓
Route Handler
    ↓
usuariosStore.js (Leer/Escribir JSON)
    ↓
usuarios.json (Datos persistentes)
    ↓
Response JSON → Frontend
    ↓
React actualiza UI
```

---

## 📝 Próximas Mejoras Posibles

- [ ] Filtrado por estado en UI
- [ ] Búsqueda de usuarios por nombre/email
- [ ] Paginación (si hay muchos usuarios)
- [ ] Exportar reporte de usuarios a CSV/PDF
- [ ] Cambio de contraseña desde admin
- [ ] Log de cambios (quién cambió qué y cuándo)
- [ ] Historial de compras por usuario
- [ ] Búsqueda avanzada

---

## 🎉 Resumen

✅ **Sistema de usuarios completamente funcional**
✅ **Admin puede ver y controlar todos los usuarios**
✅ **Datos persistentes sin MongoDB**
✅ **UI profesional y responsiva**
✅ **API segura con JWT**
✅ **Fácil de expandir y mejorar**

---

*Implementado: 17 de Diciembre de 2025*
