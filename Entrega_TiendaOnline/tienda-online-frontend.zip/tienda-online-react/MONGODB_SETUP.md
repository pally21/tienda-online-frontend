# 🍃 Guía Completa: MongoDB Atlas + Node.js

## 📌 Paso 1: Crear Cuenta en MongoDB Atlas

### 1.1 Registro
1. Ir a: https://www.mongodb.com/cloud/atlas
2. Click en "Try Free"
3. Crear cuenta con:
   - Email
   - Password
   - Nombre

### 1.2 Crear Organización
- Nombre: TiendaOnline
- Company: Tu nombre
- Continuar

### 1.3 Crear Proyecto
- Project Name: `tienda-online-db`
- Continue

---

## 📍 Paso 2: Crear Cluster (Servidor de BD)

### 2.1 Seleccionar Plan
- ✅ **Selecciona "M0 (Free)"** - Completamente gratis
- Click "Create"

### 2.2 Configuración del Cluster
- Cloud Provider: **AWS** (o Google Cloud, Azure)
- Region: **us-east-1** (o la más cercana)
- Click "Create Cluster"

**Espera 2-5 minutos mientras se crea el cluster...**

---

## 🔑 Paso 3: Crear Usuario y Contraseña

### 3.1 Database Access
1. En el sidebar izquierdo: "Database Access"
2. Click "Add Database User"
3. Llenar datos:
   - **Username**: `admin_tienda`
   - **Password**: Generar contraseña segura
   - Copy la contraseña en lugar seguro

### 3.2 Permisos
- Built-in Role: "Atlas Admin"
- Click "Add User"

---

## 🌐 Paso 4: Obtener Connection String

### 4.1 Abrir Connection String
1. En sidebar: "Database"
2. Click en tu cluster
3. Click "Connect"
4. Seleccionar: "Drivers"
5. Language: "Node.js"
6. Version: 4.1 or later

### 4.2 Copiar Cadena de Conexión

```
mongodb+srv://admin_tienda:<PASSWORD>@cluster0.xxxxx.mongodb.net/tienda_online?retryWrites=true&w=majority
```

**Reemplaza:**
- `<PASSWORD>` con tu contraseña de usuario
- `tienda_online` es el nombre de tu base de datos

**Ejemplo real:**
```
mongodb+srv://admin_tienda:MiContraseña123@cluster0.a1b2c3.mongodb.net/tienda_online?retryWrites=true&w=majority
```

---

## 💾 Paso 5: Configurar Archivo .env en Backend

### 5.1 Crear archivo `.env` en `/backend`

```bash
# Base de datos
MONGODB_URI=mongodb+srv://admin_tienda:MiContraseña123@cluster0.a1b2c3.mongodb.net/tienda_online?retryWrites=true&w=majority

# JWT
JWT_SECRET=secreto_tienda_online_2025

# Server
PORT=3001
NODE_ENV=development
```

### 5.2 Instalar dotenv
```bash
cd backend
npm install dotenv
```

---

## 🔗 Paso 6: Instalar Mongoose (ORM para MongoDB)

```bash
npm install mongoose
```

---

## 📄 Paso 7: Crear Modelo de Usuarios

Archivo: `/backend/models/Usuario.js`

```javascript
const mongoose = require('mongoose');
const bcryptjs = require('bcryptjs');

const usuarioSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: [true, 'El nombre es requerido'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'El email es requerido'],
    unique: true,
    lowercase: true,
    match: [/.+@.+\..+/, 'Email inválido']
  },
  password: {
    type: String,
    required: [true, 'La contraseña es requerida'],
    minlength: 6,
    select: false // No incluir en consultas por defecto
  },
  role: {
    type: String,
    enum: ['USER', 'ADMIN'],
    default: 'USER'
  },
  estado: {
    type: String,
    enum: ['activo', 'suspendido', 'inactivo'],
    default: 'activo'
  },
  fechaRegistro: {
    type: Date,
    default: Date.now
  },
  ultimaCompra: Date,
  apellido: String,
  direccion: String
});

// Hash password antes de guardar
usuarioSchema.pre('save', async function(next) {
  if (!this.isModified('password')) return next();
  
  this.password = await bcryptjs.hash(this.password, 10);
  next();
});

module.exports = mongoose.model('Usuario', usuarioSchema);
```

---

## 🛒 Paso 8: Crear Modelo de Productos

Archivo: `/backend/models/Producto.js`

```javascript
const mongoose = require('mongoose');

const productoSchema = new mongoose.Schema({
  nombre: {
    type: String,
    required: [true, 'El nombre es requerido']
  },
  descripcion: String,
  precio: {
    type: Number,
    required: [true, 'El precio es requerido'],
    min: 0
  },
  categoria: String,
  stock: {
    type: Number,
    default: 0,
    min: 0
  },
  imagen: String,
  activo: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Producto', productoSchema);
```

---

## 📦 Paso 9: Crear Modelo de Pedidos

Archivo: `/backend/models/Pedido.js`

```javascript
const mongoose = require('mongoose');

const pedidoSchema = new mongoose.Schema({
  usuario: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Usuario',
    required: true
  },
  items: [
    {
      producto: {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'Producto'
      },
      nombre: String,
      precio: Number,
      cantidad: Number
    }
  ],
  total: {
    type: Number,
    required: true
  },
  estado: {
    type: String,
    enum: ['Pendiente', 'Procesando', 'Enviado', 'Entregado', 'Cancelado'],
    default: 'Pendiente'
  },
  cliente: {
    nombre: String,
    email: String,
    telefono: String,
    direccion: String,
    comuna: String,
    region: String
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Pedido', pedidoSchema);
```

---

## 🔌 Paso 10: Actualizar server.js para Usar MongoDB

Archivo: `/backend/server.js` (REEMPLAZAR)

```javascript
require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcryptjs = require('bcryptjs');

const Usuario = require('./models/Usuario');
const Producto = require('./models/Producto');
const Pedido = require('./models/Pedido');

const app = express();

// Middlewares
app.use(cors());
app.use(express.json());

// Conexión a MongoDB
mongoose.connect(process.env.MONGODB_URI)
  .then(() => {
    console.log('✅ Conectado a MongoDB Atlas');
  })
  .catch(err => {
    console.error('❌ Error conectando a MongoDB:', err.message);
    process.exit(1);
  });

const JWT_SECRET = process.env.JWT_SECRET || 'secreto_tienda_online_2025';

// Middleware de autenticación
const authenticateToken = (req, res, next) => {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) return res.status(401).json({ error: 'No token' });

  try {
    const decoded = jwt.verify(token, JWT_SECRET);
    req.usuario = decoded;
    next();
  } catch {
    res.status(403).json({ error: 'Token inválido' });
  }
};

// RUTAS DE AUTENTICACIÓN
app.post('/api/auth/register', async (req, res) => {
  try {
    const { nombre, email, password } = req.body;

    // Verificar que no existe el email
    const usuarioExistente = await Usuario.findOne({ email });
    if (usuarioExistente) {
      return res.status(400).json({ error: 'El email ya está registrado' });
    }

    // Crear nuevo usuario
    const nuevoUsuario = new Usuario({
      nombre,
      email,
      password
    });

    await nuevoUsuario.save();

    const token = jwt.sign(
      { id: nuevoUsuario._id, email: nuevoUsuario.email, role: nuevoUsuario.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      token,
      usuario: {
        id: nuevoUsuario._id,
        nombre: nuevoUsuario.nombre,
        email: nuevoUsuario.email,
        role: nuevoUsuario.role
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/auth/login', async (req, res) => {
  try {
    const { email, password } = req.body;

    // Buscar usuario
    const usuario = await Usuario.findOne({ email }).select('+password');
    if (!usuario) {
      return res.status(401).json({ error: 'Email no encontrado' });
    }

    // Verificar contraseña
    const passwordValida = await bcryptjs.compare(password, usuario.password);
    if (!passwordValida) {
      return res.status(401).json({ error: 'Contraseña incorrecta' });
    }

    const token = jwt.sign(
      { id: usuario._id, email: usuario.email, role: usuario.role },
      JWT_SECRET,
      { expiresIn: '7d' }
    );

    res.json({
      success: true,
      token,
      usuario: {
        id: usuario._id,
        nombre: usuario.nombre,
        email: usuario.email,
        role: usuario.role
      }
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// RUTAS DE PRODUCTOS
app.get('/api/productos', async (req, res) => {
  try {
    const productos = await Producto.find({ activo: true });
    res.json({ success: true, data: productos });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.post('/api/productos', authenticateToken, async (req, res) => {
  try {
    if (req.usuario.role !== 'ADMIN') {
      return res.status(403).json({ error: 'No autorizado' });
    }

    const nuevoProducto = new Producto(req.body);
    await nuevoProducto.save();

    res.json({ success: true, data: nuevoProducto });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// RUTAS DE USUARIOS (ADMIN)
app.get('/api/admin/usuarios', authenticateToken, async (req, res) => {
  try {
    if (req.usuario.role !== 'ADMIN') {
      return res.status(403).json({ error: 'No autorizado' });
    }

    const usuarios = await Usuario.find().select('-password');
    res.json({ success: true, data: usuarios });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

app.put('/api/admin/usuarios/:id/estado', authenticateToken, async (req, res) => {
  try {
    if (req.usuario.role !== 'ADMIN') {
      return res.status(403).json({ error: 'No autorizado' });
    }

    const { estado } = req.body;
    const usuario = await Usuario.findByIdAndUpdate(
      req.params.id,
      { estado },
      { new: true }
    ).select('-password');

    res.json({ success: true, data: usuario });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => {
  console.log(`🚀 Servidor ejecutándose en puerto ${PORT}`);
  console.log(`📦 MongoDB Atlas conectado`);
});
```

---

## ✅ Paso 11: Verificar Conexión

```bash
cd backend
npm start
```

**Deberías ver:**
```
✅ Conectado a MongoDB Atlas
🚀 Servidor ejecutándose en puerto 3001
```

---

## 🧪 Paso 12: Pruebas

### Test 1: Registrar usuario
```bash
curl -X POST http://localhost:3001/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{
    "nombre": "Juan Pérez",
    "email": "juan@example.com",
    "password": "password123"
  }' | jq
```

### Test 2: Login
```bash
curl -X POST http://localhost:3001/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{
    "email": "admin@tienda.com",
    "password": "admin123"
  }' | jq
```

---

## 📊 Ver Datos en MongoDB Atlas

1. En Atlas: "Database"
2. Click "Browse Collections"
3. Selecciona tu cluster
4. Verás las colecciones:
   - `usuarios`
   - `productos`
   - `pedidos`

---

## 🔒 Notas de Seguridad

1. **NUNCA** commits el archivo `.env`
2. Agrega a `.gitignore`:
   ```
   .env
   .env.local
   ```

3. Usa variables de entorno en producción

---

## 🎉 ¡Listo!

✅ MongoDB Atlas configurado
✅ Mongoose instalado
✅ Modelos creados
✅ Conexión establecida
✅ Rutas funcionando

Tu aplicación ahora usa **MongoDB en la nube** 🍃
