# 🧪 PRUEBAS INTERACTIVAS: INTEGRACIÓN REST API

## 📋 Tabla de Contenidos

1. [Verificar que los servidores estén corriendo](#1-verificar-servidores)
2. [Prueba 1: Login (POST /auth/login)](#2-login)
3. [Prueba 2: Obtener Productos (GET /productos)](#3-productos)
4. [Prueba 3: Crear Pedido (POST /pedidos)](#4-crear-pedido)
5. [Prueba 4: Obtener Pedidos (GET /pedidos)](#5-obtener-pedidos)
6. [Análisis en DevTools](#devtools)

---

## 1️⃣ Verificar que los servidores estén corriendo

**Terminal 1 - Backend (puerto 3001):**
```bash
cd /Users/usuario/tienda-online-react/backend
node server-demo.js

# Resultado esperado:
# Server corriendo en puerto 3001 ✅
```

**Terminal 2 - Frontend (puerto 3000):**
```bash
cd /Users/usuario/tienda-online-react
npm start

# Resultado esperado:
# Compiled successfully! ✅
# You can now view tienda-online-react in the browser at: http://localhost:3000
```

---

## 2️⃣ Prueba 1: LOGIN

### Opción A: cURL (desde terminal)

```bash
# 1. Login como ADMIN
curl -X POST -H "Content-Type: application/json" \
  -d '{"email":"admin@tienda.com","password":"admin123"}' \
  http://localhost:3001/api/auth/login | python3 -m json.tool

# Respuesta esperada:
# {
#   "success": true,
#   "message": "Login exitoso",
#   "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
#   "usuario": {
#     "id": 1,
#     "nombre": "Admin",
#     "email": "admin@tienda.com",
#     "role": "ADMIN"
#   }
# }


# 2. Guardar el token en variable (para usarlo luego)
TOKEN=$(curl -s -X POST -H "Content-Type: application/json" \
  -d '{"email":"admin@tienda.com","password":"admin123"}' \
  http://localhost:3001/api/auth/login | python3 -c "import sys, json; print(json.load(sys.stdin)['token'])")

echo "✅ Token guardado: $TOKEN"
```

### Opción B: Postman / Thunder Client

1. **Method:** POST
2. **URL:** `http://localhost:3001/api/auth/login`
3. **Headers:**
   ```
   Content-Type: application/json
   ```
4. **Body (raw JSON):**
   ```json
   {
     "email": "admin@tienda.com",
     "password": "admin123"
   }
   ```
5. **Click: Send**

**Resultado esperado:** Status 200 con token y datos de usuario

### Opción C: Desde el Navegador

1. Abre http://localhost:3000/login
2. Ingresa:
   - Email: `admin@tienda.com`
   - Password: `admin123`
3. Click en "Entrar"
4. Abre DevTools (F12 → Console) y verás logs como:
   ```
   📡 POST /auth/login {hasToken: false}
   Response Status: 200 {success: true, ...}
   ```

---

## 3️⃣ Prueba 2: OBTENER PRODUCTOS

### Opción A: cURL

```bash
# SIN token (debería funcionar igual)
curl -s http://localhost:3001/api/productos | python3 -m json.tool

# Respuesta esperada (primeros 2 productos):
# {
#   "success": true,
#   "message": "Productos obtenidos correctamente",
#   "data": [
#     {
#       "id": 1,
#       "nombre": "MacBook Pro 16\"",
#       "precio": 3499000,
#       "categoria": "Electrónica",
#       "stock": 5
#     },
#     {
#       "id": 3,
#       "nombre": "Magic Mouse",
#       "precio": 79000,
#       "categoria": "Accesorios",
#       "stock": 15
#     },
#     ...
#   ]
# }


# CON token (más información)
curl -s -H "Authorization: Bearer $TOKEN" \
  http://localhost:3001/api/productos | python3 -m json.tool

# Contar cuántos productos hay
curl -s http://localhost:3001/api/productos | python3 -c "import sys, json; print('Total productos:', len(json.load(sys.stdin)['data']))"
# Resultado: Total productos: 6
```

### Opción B: Desde el Navegador

1. Abre http://localhost:3000/productos
2. Deberías ver 6 tarjetas de productos con:
   - Imágenes de Unsplash
   - Nombres (MacBook, Mouse, Keyboard, AirPods, iPad, Monitor)
   - Precios en CLP ($3.499.000, $79.000, etc.)
   - Botón "Agregar al Carrito"

3. Abre DevTools (F12 → Network Tab)
4. Refresca la página (Cmd+R)
5. Deberías ver request:
   ```
   GET http://localhost:3001/api/productos
   Status: 200 OK
   Size: 2.5 KB
   Time: ~45ms
   ```

6. Click en el request → Preview → verás JSON con 6 productos

---

## 4️⃣ Prueba 3: CREAR PEDIDO

### Paso 1: Obtener token (si no lo tienes)

```bash
TOKEN=$(curl -s -X POST -H "Content-Type: application/json" \
  -d '{"email":"admin@tienda.com","password":"admin123"}' \
  http://localhost:3001/api/auth/login | python3 -c "import sys, json; print(json.load(sys.stdin)['token'])")

echo "Token: $TOKEN"
```

### Paso 2: Crear pedido (cURL)

```bash
curl -X POST -H "Content-Type: application/json" \
  -H "Authorization: Bearer $TOKEN" \
  -d '{
    "items": [
      {"id": 1, "nombre": "MacBook Pro 16\"", "precio": 3499000, "cantidad": 1},
      {"id": 5, "nombre": "AirPods Pro", "precio": 349000, "cantidad": 1}
    ],
    "total": 3848000,
    "cliente": {
      "nombre": "Juan Pérez",
      "email": "juan@example.com",
      "telefono": "+56912345678",
      "direccion": "Calle Principal 123, Santiago",
      "comuna": "Providencia",
      "region": "Metropolitana"
    }
  }' \
  http://localhost:3001/api/pedidos | python3 -m json.tool

# Respuesta esperada:
# {
#   "success": true,
#   "message": "Pedido creado exitosamente",
#   "data": {
#     "id": "PED-2025-001",
#     "fecha": "2025-12-17T10:30:00Z",
#     "items": [...],
#     "total": 3848000,
#     "estado": "PENDIENTE",
#     "cliente": {...}
#   }
# }
```

### Paso 3: Desde el Navegador

1. Abre http://localhost:3000
2. Inicia sesión (admin@tienda.com / admin123)
3. Ve a "Productos" (http://localhost:3000/productos)
4. Agrega 2-3 productos al carrito:
   - Click en [Agregar al Carrito] en cada producto
5. Ve al carrito (http://localhost:3000/carrito)
6. Click en "Proceder al Checkout"
7. Completa el formulario:
   ```
   Nombre: Juan Pérez
   Email: juan@example.com
   Teléfono: +56912345678
   Dirección: Calle Principal 123, Santiago
   Comuna: Providencia
   Región: Metropolitana
   ```
8. Click en "Confirmar Pedido"
9. Deberías ver página de confirmación con:
   - ✅ Número de pedido (PED-2025-XXX)
   - Fecha y hora
   - Lista de productos
   - Total: $XXXX.XXX
   - Estado: 🟡 PENDIENTE

**En DevTools (Network Tab):**
```
POST http://localhost:3001/api/pedidos
Status: 200 OK
Authorization: Bearer <token>
Response: {success: true, data: {...}}
```

---

## 5️⃣ Prueba 4: OBTENER PEDIDOS

### Opción A: cURL

```bash
# Obtener token
TOKEN=$(curl -s -X POST -H "Content-Type: application/json" \
  -d '{"email":"admin@tienda.com","password":"admin123"}' \
  http://localhost:3001/api/auth/login | python3 -c "import sys, json; print(json.load(sys.stdin)['token'])")

# Obtener pedidos del usuario
curl -s -H "Authorization: Bearer $TOKEN" \
  http://localhost:3001/api/pedidos | python3 -m json.tool

# Respuesta esperada (si creaste pedidos):
# {
#   "success": true,
#   "message": "Pedidos obtenidos correctamente",
#   "data": [
#     {
#       "id": "PED-2025-001",
#       "fecha": "2025-12-17T10:30:00Z",
#       "items": [...],
#       "total": 3848000,
#       "estado": "PENDIENTE"
#     }
#   ]
# }


# Contar pedidos
curl -s -H "Authorization: Bearer $TOKEN" \
  http://localhost:3001/api/pedidos | python3 -c "import sys, json; print('Total pedidos:', len(json.load(sys.stdin)['data']))"
```

### Opción B: Desde el Navegador

1. Abre http://localhost:3000/mis-pedidos
2. Deberías ver lista de todos tus pedidos con:
   - Número de pedido
   - Fecha
   - Total
   - Estado
   - Botón "Ver Detalles"

3. Abre DevTools (F12 → Network Tab)
4. Busca request a `/api/pedidos`
5. Verás respuesta JSON con array de pedidos

---

## 🔍 DevTools: Análisis Detallado

### Abrir DevTools
- Windows/Linux: `F12` o `Ctrl+Shift+I`
- Mac: `Cmd+Option+I`

### Tab: Console (Consola)

**Cuando haces login, verás logs como:**
```
📡 POST /auth/login {
  hasToken: false,
  headers: {
    "Content-Type": "application/json"
  }
}

Response Status: 200 {
  success: true,
  message: "Login exitoso",
  token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...",
  usuario: {
    id: 1,
    nombre: "Admin",
    email: "admin@tienda.com",
    role: "ADMIN"
  }
}
```

**Cuando cargas productos:**
```
📡 GET /productos {
  hasToken: true,
  headers: {
    "Content-Type": "application/json",
    "Authorization": "Bearer eyJ..."
  }
}

Response Status: 200 {
  success: true,
  data: Array(6)
}
```

### Tab: Network (Red)

1. Abre DevTools
2. Selecciona tab "Network"
3. Haz login o carga productos
4. Verás requests como:

**LOGIN:**
```
POST /api/auth/login
Status: 200 OK
Size: 1.2 KB
Time: 25ms
```

**PRODUCTOS:**
```
GET /api/productos
Status: 200 OK
Size: 2.5 KB
Time: 45ms
```

**CREAR PEDIDO:**
```
POST /api/pedidos
Status: 200 OK
Size: 1.8 KB
Time: 60ms
```

### Tab: Storage (Almacenamiento)

Verás qué datos guarda el frontend en localStorage:

**Application → Local Storage → http://localhost:3000**
```
token: eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...
usuario: {"id":1,"nombre":"Admin","email":"admin@tienda.com","role":"ADMIN"}
role: ADMIN
```

---

## 📊 Tabla Resumen: Estados HTTP

| Código | Significado | Ejemplo |
|--------|--|--|
| **200** | OK - Exitoso | GET productos ✅ |
| **201** | Created - Recurso creado | POST pedido ✅ |
| **400** | Bad Request - Datos inválidos | Falta email/password ❌ |
| **401** | Unauthorized - Sin autenticación | Sin token ❌ |
| **403** | Forbidden - Sin permiso | Usuario normal intentando crear producto ❌ |
| **404** | Not Found - No existe | Producto ID 999 ❌ |
| **500** | Server Error - Error del servidor | Backend crash ❌ |

---

## 🔐 Notas Importantes: Seguridad

### Tokens JWT

```javascript
// Cuando haces login, recibes un token que debes usar en requests posteriores
token: "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpZCI6MSwibm9tYnJlIjoiQWRtaW4iLCJyb2xlIjoiQURNSU4ifQ.signature..."

// Este token se guarda en localStorage
localStorage.getItem('token') // → "eyJ..."

// Y se incluye en todos los requests posteriores
Authorization: Bearer eyJ...
```

### Sin token vs Con token

```bash
# SIN token - Solo GET públicos funcionan
curl http://localhost:3001/api/productos ✅

# CON token - Acceso a datos privados
curl -H "Authorization: Bearer TOKEN" http://localhost:3001/api/pedidos ✅

# SIN token a ruta protegida - FALLA
curl http://localhost:3001/api/pedidos ❌
# Response: {"success": false, "message": "Token no proporcionado", "code": 401}
```

---

## ✅ Checklist: Todas las Pruebas Completadas

**Backend:**
- [ ] Servidor Node.js corriendo en puerto 3001
- [ ] GET /api/productos devuelve 6 productos
- [ ] POST /api/auth/login devuelve token
- [ ] POST /api/pedidos crea pedido exitosamente
- [ ] GET /api/pedidos devuelve lista de pedidos

**Frontend:**
- [ ] Página carga sin errores en localhost:3000
- [ ] Login funciona (admin@tienda.com / admin123)
- [ ] Página productos muestra 6 tarjetas
- [ ] Botón "Agregar al Carrito" funciona
- [ ] Carrito muestra items correctamente
- [ ] Checkout guarda datos del cliente
- [ ] Pedido se crea exitosamente
- [ ] Página confirmación muestra número de pedido

**DevTools:**
- [ ] Console muestra logs de requests (📡 POST, GET)
- [ ] Network tab muestra requests con Status 200
- [ ] Storage muestra token guardado en localStorage
- [ ] Response JSON está bien formado

---

## 🐛 Troubleshooting

### Error: "Cannot POST /api/auth/login"

```
❌ Problema: Servidor backend no está corriendo
✅ Solución: cd backend && node server-demo.js
```

### Error: "Failed to fetch" en el navegador

```
❌ Problema: Frontend no puede conectar al backend
✅ Solución: 
  1. Verifica que backend esté corriendo en :3001
  2. Verifica que frontend esté en :3000
  3. Abre DevTools Console para ver error exacto
```

### Error: "CORS error"

```
❌ Problema: Frontend y backend no tienen CORS configurado
✅ Solución: Backend tiene CORS habilitado automáticamente
  Si ves error, verifica que backend esté compilado correctamente
```

### Error: "Token inválido"

```
❌ Problema: Token expirado o mal formado
✅ Solución:
  1. Haz login de nuevo para obtener nuevo token
  2. Verifica que el token esté en localStorage
  3. No edites el token manualmente
```

### Error: "Producto no encontrado"

```
❌ Problema: Intentaste acceder a producto con ID inexistente
✅ Solución: 
  1. GET /api/productos para ver IDs disponibles
  2. Los productos disponibles tienen IDs: 1, 3, 4, 5, 6, 7
```

---

## 📈 Flujo Completo: Paso a Paso

```
1. USUARIO ENTRA AL SITIO
   ↓
2. VE PÁGINA INICIAL (Home.jsx)
   ↓
3. HACE CLICK EN "PRODUCTOS"
   ↓
4. FRONTEND → GET /api/productos (sin token)
   ↓
5. BACKEND → Retorna 6 productos en JSON
   ↓
6. FRONTEND → Renderiza ProductCard para cada uno
   ↓
7. USUARIO VE 6 TARJETAS CON IMÁGENES Y PRECIOS
   ↓
8. USUARIO HACE CLICK EN "AGREGAR AL CARRITO"
   ↓
9. FRONTEND → CarritoContext se actualiza (LOCAL)
   ↓
10. USUARIO NAVEGA A "/carrito"
   ↓
11. USUARIO VE RESUMEN DEL CARRITO
   ↓
12. USUARIO HACE CLICK EN "PROCEDER AL CHECKOUT"
   ↓
13. USUARIO VE FORMULARIO DE ENVÍO
   ↓
14. USUARIO COMPLETA DATOS Y HACE CLICK "CONFIRMAR"
   ↓
15. FRONTEND → POST /api/pedidos (CON TOKEN)
   ↓
16. BACKEND → Valida token, crea pedido
   ↓
17. BACKEND → Retorna ID de pedido (PED-2025-001)
   ↓
18. FRONTEND → Redirige a /pedido-confirmado
   ↓
19. USUARIO VE CONFIRMACIÓN CON NÚMERO DE PEDIDO ✅
```

---

**Creado:** 17/12/2025  
**Archivo:** TEST_INTEGRACION_REST_API.md

Todas las pruebas pueden ejecutarse inmediatamente sin instalaciones adicionales.
