import React, { useState, useEffect } from 'react';
import { Container, Row, Col, Table, Button, Badge, Modal, Alert, Spinner } from 'react-bootstrap';
import { useAuth } from '../../context/AuthContext';
import { useNavigate } from 'react-router-dom';
import './AdminUsuarios.css';

const AdminUsuarios = () => {
  const { estaAutenticado, esAdmin } = useAuth();
  const navigate = useNavigate();
  
  const [usuarios, setUsuarios] = useState([]);
  const [cargando, setCargando] = useState(true);
  const [error, setError] = useState('');
  const [estadisticas, setEstadisticas] = useState(null);
  const [showModal, setShowModal] = useState(false);
  const [usuarioSeleccionado, setUsuarioSeleccionado] = useState(null);
  const [nuevoEstado, setNuevoEstado] = useState('');
  const [mensaje, setMensaje] = useState('');

  // Verificar que sea admin
  useEffect(() => {
    if (!estaAutenticado || !esAdmin) {
      navigate('/login');
      return;
    }
  }, [estaAutenticado, esAdmin, navigate]);

  // Cargar usuarios y estadísticas
  useEffect(() => {
    cargarDatos();
  }, []);

  const cargarDatos = async () => {
    try {
      setCargando(true);
      setError('');
      
      const token = localStorage.getItem('token');

      // Obtener usuarios
      const respUsuarios = await fetch('http://localhost:3001/api/admin/usuarios', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (!respUsuarios.ok) {
        throw new Error('Error al cargar usuarios');
      }

      const dataUsuarios = await respUsuarios.json();
      setUsuarios(dataUsuarios.data || []);

      // Obtener estadísticas
      const respEstad = await fetch('http://localhost:3001/api/admin/estadisticas/usuarios', {
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      if (respEstad.ok) {
        const dataEstad = await respEstad.json();
        setEstadisticas(dataEstad.data);
      }
    } catch (err) {
      setError(err.message || 'Error al cargar datos');
      console.error('Error:', err);
    } finally {
      setCargando(false);
    }
  };

  const abrirModalEstado = (usuario) => {
    setUsuarioSeleccionado(usuario);
    setNuevoEstado(usuario.estado);
    setShowModal(true);
  };

  const actualizarEstado = async () => {
    try {
      setMensaje('');
      const token = localStorage.getItem('token');

      const resp = await fetch(`http://localhost:3001/api/admin/usuarios/${usuarioSeleccionado.id}/estado`, {
        method: 'PUT',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        },
        body: JSON.stringify({ estado: nuevoEstado })
      });

      const data = await resp.json();

      if (!resp.ok) {
        setMensaje(`❌ ${data.error || 'Error al actualizar'}`);
        return;
      }

      setMensaje(`✅ ${data.message}`);
      setShowModal(false);
      cargarDatos();
    } catch (err) {
      setMensaje(`❌ ${err.message}`);
    }
  };

  const eliminarUsuario = async (idUsuario, email) => {
    if (!window.confirm(`¿Estás seguro de que deseas eliminar a ${email}?`)) {
      return;
    }

    try {
      setMensaje('');
      const token = localStorage.getItem('token');

      const resp = await fetch(`http://localhost:3001/api/admin/usuarios/${idUsuario}`, {
        method: 'DELETE',
        headers: {
          'Authorization': `Bearer ${token}`,
          'Content-Type': 'application/json'
        }
      });

      const data = await resp.json();

      if (!resp.ok) {
        setMensaje(`❌ ${data.error || 'Error al eliminar'}`);
        return;
      }

      setMensaje(`✅ ${data.message}`);
      cargarDatos();
    } catch (err) {
      setMensaje(`❌ ${err.message}`);
    }
  };

  const obtenerBadgeEstado = (estado) => {
    switch (estado) {
      case 'activo':
        return <Badge bg="success">Activo</Badge>;
      case 'suspendido':
        return <Badge bg="warning">Suspendido</Badge>;
      case 'inactivo':
        return <Badge bg="secondary">Inactivo</Badge>;
      default:
        return <Badge bg="danger">Desconocido</Badge>;
    }
  };

  const obtenerBadgeRole = (role) => {
    return role === 'ADMIN' ? (
      <Badge bg="danger">Admin</Badge>
    ) : (
      <Badge bg="info">Usuario</Badge>
    );
  };

  if (cargando) {
    return (
      <Container className="admin-usuarios-page py-5">
        <div className="text-center">
          <Spinner animation="border" role="status">
            <span className="visually-hidden">Cargando...</span>
          </Spinner>
        </div>
      </Container>
    );
  }

  return (
    <Container className="admin-usuarios-page py-5">
      <Row className="mb-5">
        <Col>
          <h1 className="display-4 mb-4">👥 Gestión de Usuarios</h1>
          
          {error && <Alert variant="danger">{error}</Alert>}
          {mensaje && (
            <Alert variant={mensaje.includes('✅') ? 'success' : 'danger'} dismissible onClose={() => setMensaje('')}>
              {mensaje}
            </Alert>
          )}
        </Col>
      </Row>

      {/* Estadísticas */}
      {estadisticas && (
        <Row className="mb-5">
          <Col md={3} className="mb-3">
            <div className="stat-card">
              <h3 className="stat-number">{estadisticas.totalUsuarios}</h3>
              <p className="stat-label">Total de Usuarios</p>
            </div>
          </Col>
          <Col md={3} className="mb-3">
            <div className="stat-card">
              <h3 className="stat-number">{estadisticas.usuariosActivos}</h3>
              <p className="stat-label">Usuarios Activos</p>
            </div>
          </Col>
          <Col md={3} className="mb-3">
            <div className="stat-card">
              <h3 className="stat-number">{estadisticas.usuariosSuspendidos}</h3>
              <p className="stat-label">Usuarios Suspendidos</p>
            </div>
          </Col>
          <Col md={3} className="mb-3">
            <div className="stat-card">
              <h3 className="stat-number">{estadisticas.usuariosConCompras}</h3>
              <p className="stat-label">Con Compras</p>
            </div>
          </Col>
        </Row>
      )}

      {/* Tabla de usuarios */}
      <Row>
        <Col>
          <div className="table-responsive">
            <Table hover striped className="admin-usuarios-table">
              <thead>
                <tr>
                  <th>ID</th>
                  <th>Nombre</th>
                  <th>Email</th>
                  <th>Rol</th>
                  <th>Estado</th>
                  <th>Registro</th>
                  <th>Última Compra</th>
                  <th>Acciones</th>
                </tr>
              </thead>
              <tbody>
                {usuarios.map((usuario) => (
                  <tr key={usuario.id}>
                    <td>{usuario.id}</td>
                    <td>{usuario.nombre}</td>
                    <td>{usuario.email}</td>
                    <td>{obtenerBadgeRole(usuario.role)}</td>
                    <td>{obtenerBadgeEstado(usuario.estado)}</td>
                    <td>{new Date(usuario.fechaRegistro).toLocaleDateString('es-CL')}</td>
                    <td>
                      {usuario.ultimaCompra 
                        ? new Date(usuario.ultimaCompra).toLocaleDateString('es-CL')
                        : '—'
                      }
                    </td>
                    <td>
                      {usuario.id !== 1 && (
                        <div className="btn-group-sm d-flex gap-2">
                          <Button 
                            variant="outline-primary" 
                            size="sm"
                            onClick={() => abrirModalEstado(usuario)}
                          >
                            Estado
                          </Button>
                          <Button 
                            variant="outline-danger" 
                            size="sm"
                            onClick={() => eliminarUsuario(usuario.id, usuario.email)}
                          >
                            Eliminar
                          </Button>
                        </div>
                      )}
                      {usuario.id === 1 && (
                        <span className="text-muted small">Admin Principal</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </Table>
          </div>

          {usuarios.length === 0 && (
            <Alert variant="info" className="text-center">
              No hay usuarios registrados
            </Alert>
          )}
        </Col>
      </Row>

      {/* Modal para cambiar estado */}
      <Modal show={showModal} onHide={() => setShowModal(false)} centered>
        <Modal.Header closeButton>
          <Modal.Title>Cambiar Estado de Usuario</Modal.Title>
        </Modal.Header>
        <Modal.Body>
          {usuarioSeleccionado && (
            <>
              <p>
                <strong>Usuario:</strong> {usuarioSeleccionado.nombre}
              </p>
              <p>
                <strong>Email:</strong> {usuarioSeleccionado.email}
              </p>
              <div className="form-group">
                <label><strong>Nuevo Estado:</strong></label>
                <select 
                  className="form-control"
                  value={nuevoEstado}
                  onChange={(e) => setNuevoEstado(e.target.value)}
                >
                  <option value="activo">Activo</option>
                  <option value="suspendido">Suspendido</option>
                  <option value="inactivo">Inactivo</option>
                </select>
              </div>
            </>
          )}
        </Modal.Body>
        <Modal.Footer>
          <Button variant="secondary" onClick={() => setShowModal(false)}>
            Cancelar
          </Button>
          <Button variant="primary" onClick={actualizarEstado}>
            Actualizar Estado
          </Button>
        </Modal.Footer>
      </Modal>
    </Container>
  );
};

export default AdminUsuarios;
